from kivy.lang import Builder
from kivy.core.window import Window
from kivymd.app import MDApp
from kivy.uix.screenmanager import ScreenManager, NoTransition

from screens.login_screen import LoginScreen
from screens.dashboard_screen import DashboardScreen
from utils.lang import Translator

class NetworkApp(MDApp):
    def build(self):
        Window.size = (360, 640)  # taille pour tests
        self.title = "Network Analyzer"
        self.theme_cls.primary_palette = "BlueGray"
        self.translator = Translator()

        # Initialisation du ScreenManager
        self.manager = ScreenManager(transition=NoTransition())

        self.login_screen = LoginScreen(name='login')
        self.dashboard_screen = DashboardScreen(name='dashboard')

        self.manager.add_widget(self.login_screen)
        self.manager.add_widget(self.dashboard_screen)

        return self.manager

    def change_language(self, lang_code):
        self.translator.set_language(lang_code)
        self.login_screen.update_language()
        self.dashboard_screen.update_language()

    def switch_to_dashboard(self, user_role):
        self.dashboard_screen.set_user_role(user_role)
        self.manager.current = "dashboard"

    def switch_to_login(self):
        self.manager.current = "login"

    def toggle_nav_drawer(self):
        if self.dashboard_screen.ids.nav_drawer.state == "open":
            self.dashboard_screen.ids.nav_drawer.set_state("close")
        else:
            self.dashboard_screen.ids.nav_drawer.set_state("open")

if __name__ == "__main__":
    NetworkApp().run()
