from kivymd.uix.screen import MDScreen
from kivymd.toast import toast
from kivy.lang import Builder
from kivy.clock import Clock
import random

Builder.load_file("kivy_files/dashboard.kv")

class DashboardScreen(MDScreen):
    def on_enter(self):
        Clock.schedule_interval(self.update_stats, 2)

    def update_stats(self, dt):
        traffic = round(random.uniform(0.1, 2.5), 2)
        self.ids.network_stats.text = f"Trafic actuel : {traffic} Ko/s"

        protocol = random.choice(["HTTP", "HTTPS", "DNS", "TCP", "UDP"])
        percent = random.randint(30, 90)
        self.ids.protocol_stat.text = f"{protocol} : {percent}%"

        anomalies = ["Aucune anomalie", "Tentative d'intrusion détectée", "Trafic suspect détecté"]
        self.ids.anomaly_stat.text = random.choice(anomalies)

    def export_data(self):
        toast("Exportation des données en CSV...")

    def contact_admin(self):
        toast("Ouverture du chat avec l'administrateur...")

    def toggle_nav_drawer(self):
        nav_drawer = self.ids.nav_drawer
        nav_drawer.set_state("toggle")
