from kivy.uix.screenmanager import Screen
from kivymd.uix.menu import MDDropdownMenu
from kivymd.uix.snackbar import Snackbar
from kivy.properties import ObjectProperty

class LoginScreen(Screen):
    lang_menu = ObjectProperty()

    def on_kv_post(self, base_widget):
        self.build_lang_menu()

    def build_lang_menu(self):
        languages = [
            {"viewclass": "OneLineListItem", "text": "Français", "on_release": lambda x="fr": self.set_lang(x)},
            {"viewclass": "OneLineListItem", "text": "English", "on_release": lambda x="en": self.set_lang(x)},
        ]
        self.lang_menu = MDDropdownMenu(
            caller=self.ids.lang_btn,
            items=languages,
            width_mult=3,
        )

    def open_menu(self):
        if self.lang_menu:
            self.lang_menu.open()

    def set_lang(self, lang_code):
        self.lang_menu.dismiss()
        self.manager.app.change_language(lang_code)

    def login(self):
        username = self.ids.username.text
        password = self.ids.password.text
        if username == "admin" and password == "admin":
            self.manager.app.switch_to_dashboard("Admin")
        elif username and password:
            self.manager.app.switch_to_dashboard("Client")
        else:
            Snackbar(text="Nom d'utilisateur ou mot de passe invalide").open()

    def update_language(self):
        tr = self.manager.app.translator.translate
        self.ids.title_label.text = tr("Connexion")
        self.ids.username.hint_text = tr("Nom d'utilisateur")
        self.ids.password.hint_text = tr("Mot de passe")
        self.ids.login_btn.text = tr("Se connecter")
        self.ids.lang_btn.text = tr("Langue")
