from kivymd.app import MDApp
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager
from screens.login_screen import LoginScreen
from screens.dashboard_screen import DashboardScreen
from utils.lang import Translator

class NetworkApp(MDApp):
    def build(self):
        self.lang = Translator(lang="fr")  # default lang
        self.theme_cls.primary_palette = "Blue"
        Builder.load_file("kivy_files/login.kv")      # Ajout ici
        Builder.load_file("kivy_files/dashboard.kv")  # Déjà présent
        sm = ScreenManager()
        sm.add_widget(LoginScreen(name="login"))
        sm.add_widget(DashboardScreen(name="dashboard"))
        return sm

    def switch_language(self, lang):
        self.lang.set_language(lang)
        self.root.clear_widgets()
        self.root.add_widget(LoginScreen(name="login"))
        self.root.add_widget(DashboardScreen(name="dashboard"))

if __name__ == "__main__":
    NetworkApp().run()