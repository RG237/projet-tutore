from kivymd.uix.screen import MDScreen
from kivy.lang import Builder


class DashboardScreen(MDScreen):
    def load_role(self, role):
        self.ids.role_label.text = f"Rôle : {role}"
        self.ids.export_btn.disabled = role != "admin"