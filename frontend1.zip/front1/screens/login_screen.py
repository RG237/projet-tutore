from kivymd.uix.screen import MDScreen
from kivy.lang import Builder
from kivy.properties import ObjectProperty
from kivy.clock import Clock
from kivy.app import App  # Ajout de l'import

class LoginScreen(MDScreen):
    app = ObjectProperty()

    def on_pre_enter(self):
        Clock.schedule_once(self.load_texts)

    def load_texts(self, *args):
        tr = App.get_running_app().lang.gettext  # Correction ici
        self.ids.login_title.text = tr("login_title")
        self.ids.username.hint_text = tr("username")
        self.ids.password.hint_text = tr("password")
        self.ids.login_btn.text = tr("login")
        self.ids.language_label.text = tr("language")

    def do_login(self):
        username = self.ids.username.text
        password = self.ids.password.text
        role = "admin" if username == "admin" else "client"
        self.manager.current = "dashboard"
        self.manager.get_screen("dashboard").load_role(role)

    def change_language(self, lang):
        App.get_running_app().switch_language(lang)  # Correction ici