from flask import Flask, request, jsonify
import sqlite3
import logging
from logging.handlers import RotatingFileHandler
import os

app = Flask(__name__)

# === Chemins ===
DB_PATH = "logs_received.db"
LOG_DIR = "logs"
LOG_FILE = os.path.join(LOG_DIR, "server.log")

# === Authentification (token simple pour tests) ===
SECRET_TOKEN = "mon_token_secret"

# === Setup logger ===
os.makedirs(LOG_DIR, exist_ok=True)
logger = logging.getLogger("server_logger")
logger.setLevel(logging.INFO)
handler = RotatingFileHandler(LOG_FILE, maxBytes=1000000, backupCount=3)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)

# === Créer la base et la table si besoin ===
def init_database():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS received_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            event_type TEXT,
            source_ip TEXT,
            details TEXT
        )
    """)
    conn.commit()
    conn.close()
    logger.info("Base de données initialisée.")

init_database()

# === API principale ===
@app.route("/api/logs", methods=["POST"])
def receive_log():
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer ") or auth.split(" ")[1] != SECRET_TOKEN:
        logger.warning("Requête rejetée : token manquant ou invalide.")
        return jsonify({"error": "Non autorisé"}), 403

    try:
        data = request.get_json()
        timestamp = data.get("timestamp")
        event_type = data.get("event_type")
        source_ip = data.get("source_ip")
        details = data.get("details")

        if not all([timestamp, event_type, source_ip, details]):
            raise ValueError("Champs manquants")

        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO received_logs (timestamp, event_type, source_ip, details)
            VALUES (?, ?, ?, ?)
        """, (timestamp, event_type, source_ip, details))
        conn.commit()
        conn.close()
        logger.info(f"Log reçu : {timestamp} - {event_type} - {source_ip}")
        return jsonify({"status": "ok"}), 200

    except Exception as e:
        logger.error(f"Erreur lors de l'enregistrement du log : {e}")
        return jsonify({"error": "Erreur serveur"}), 500

# === Démarrage local sécurisé (si besoin) ===
if __name__ == "__main__":
    context = ("cert.pem", "key.pem")  # Certificat SSL local
    app.run(host="0.0.0.0", port=5000, ssl_context=context, debug=True)
