import unittest
from server import app
import json

class ServerTestCase(unittest.TestCase):
    def setUp(self):
        # Crée un client de test Flask
        self.client = app.test_client()
        self.headers = {
            "Authorization": "Bearer mon_token_secret"
        }

    def test_log_api_ok(self):
        # Test d’un log valide
        data = {
            "timestamp": "2025-06-28T15:00:00",
            "event_type": "INFO",
            "source_ip": "127.0.0.1",
            "details": "Test de log depuis unitaire"
        }
        response = self.client.post("/api/logs", headers=self.headers,
                                    data=json.dumps(data), content_type='application/json')
        self.assertEqual(response.status_code, 200)
        self.assertIn("ok", response.get_data(as_text=True))

    def test_log_api_sans_auth(self):
        # Test sans authentification
        data = {
            "timestamp": "2025-06-28T15:00:00",
            "event_type": "ALERT",
            "source_ip": "10.0.0.1",
            "details": "Tentative sans token"
        }
        response = self.client.post("/api/logs", data=json.dumps(data), content_type='application/json')
        self.assertEqual(response.status_code, 403)

    def test_log_api_mauvais_format(self):
        # Test avec données manquantes
        data = {
            "timestamp": "incomplet"
        }
        response = self.client.post("/api/logs", headers=self.headers,
                                    data=json.dumps(data), content_type='application/json')
        # Peut retourner 500 si le champ est manquant
        self.assertTrue(response.status_code in [400, 500])

if __name__ == '__main__':
    unittest.main()
