import platform
import os
import requests
import logging
import matplotlib.pyplot as plt
from datetime import datetime
from collections import defaultdict, Counter, deque
import sqlite3
import threading
import time
from scapy.all import *
from sklearn.ensemble import IsolationForest

logging.basicConfig(
    filename="logs/client.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

DB_PATH = "data_base.db"
IS_ANDROID = platform.system() == "Linux" and "ANDROID_ARGUMENT" in os.environ

class NetworkAnalyzerBackend:
    def __init__(self):
        self.conn = sqlite3.connect(DB_PATH, check_same_thread=False)
        self.cursor = self.conn.cursor()
        self._setup_database()
        self.protocol_stats = defaultdict(int)
        self.alerts = []
        self.event_counter = Counter()
        self.capture_active = False
        self.interface = self._detect_interface()
        self.anomaly_model = IsolationForest(contamination=0.1)
        self.training_data = []
        self.captured_packets = deque(maxlen=100)

    def _setup_database(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS network_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                event_type TEXT,
                source_ip TEXT,
                details TEXT
            )
        ''')
        self.conn.commit()

    def _detect_interface(self):
        interfaces = get_if_list()
        for iface in interfaces:
            if "wlan" in iface or "eth" in iface:
                return iface
        return interfaces[0]

    def start_capture(self):
        self.capture_active = True
        thread = threading.Thread(target=self._sniff_packets)
        thread.start()

    def stop_capture(self):
        self.capture_active = False

    def _sniff_packets(self):
        sniff(iface=self.interface, prn=self._analyze_packet, stop_filter=lambda x: not self.capture_active)

    def _analyze_packet(self, packet):
        if IP in packet:
            src_ip = packet[IP].src
            proto = packet[IP].proto
            timestamp = datetime.now().isoformat()
            event_type = "INFO"
            details = f"Protocole: {proto}"

            self.protocol_stats[proto] += 1
            self.event_counter[event_type] += 1

            self._log_event(timestamp, event_type, src_ip, details)
            self._send_to_server(timestamp, event_type, src_ip, details)

    def _log_event(self, timestamp, event_type, source_ip, details):
        self.cursor.execute('''
            INSERT INTO network_logs (timestamp, event_type, source_ip, details)
            VALUES (?, ?, ?, ?)
        ''', (timestamp, event_type, source_ip, details))
        self.conn.commit()

    def _send_to_server(self, timestamp, event_type, source_ip, details):
        data = {
            "timestamp": timestamp,
            "event_type": event_type,
            "source_ip": source_ip,
            "details": details
        }
        try:
            url = "https://127.0.0.1:5000/api/logs"
            headers = {"Authorization": "Bearer mon_token_secret"}
            response = requests.post(url, json=data, headers=headers, verify=False)
            if response.status_code == 200:
                logging.info("✅ Log envoyé avec succès.")
            else:
                logging.warning(f"⚠️ Erreur lors de l’envoi : {response.status_code} - {response.text}")
        except Exception as e:
            logging.error(f"❌ Échec de l'envoi du log : {e}")

    # 🔍 Fonction ajoutée : scan des appareils connectés au réseau local
    def get_connected_devices(self, subnet="192.168.1.0/24"):
        devices = []
        try:
            arp = ARP(pdst=subnet)
            ether = Ether(dst="ff:ff:ff:ff:ff:ff")
            packet = ether / arp
            result = srp(packet, timeout=3, verbose=0)[0]
            for sent, received in result:
                devices.append({
                    "ip": received.psrc,
                    "mac": received.hwsrc
                })
        except Exception as e:
            logging.error(f"Erreur scan réseau local : {e}")
        return devices

# === Utilisation ===
if __name__ == "__main__":
    analyzer = NetworkAnalyzerBackend()
    devices = analyzer.get_connected_devices()
    print("📡 Appareils connectés sur le réseau :")
    for dev in devices:
        print(f" - IP : {dev['ip']} | MAC : {dev['mac']}")
