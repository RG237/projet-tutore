from kivymd.uix.screen import MDScreen

class DashboardScreen(MDScreen):
    def load_role(self, role):
        # Tu pourras afficher le rôle sur le dashboard ici
        pass