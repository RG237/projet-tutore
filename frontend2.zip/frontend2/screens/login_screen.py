from kivymd.uix.screen import MDScreen
from kivy.properties import ObjectProperty
from kivy.clock import Clock
from kivy.app import App

class LoginScreen(MDScreen):
    app = ObjectProperty()

    def on_pre_enter(self):
        Clock.schedule_once(self.load_texts)

    def load_texts(self, *args):
        # À compléter si tu ajoutes la traduction
        pass