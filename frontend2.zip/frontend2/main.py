from kivymd.app import MDApp
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager
from screens.login_screen import LoginScreen
from screens.dashboard_screen import DashboardScreen  # À créer si besoin

class NetworkApp(MDApp):
    def build(self):
        self.theme_cls.primary_palette = "Blue"
        Builder.load_file("kivy_files/login.kv")
        Builder.load_file("kivy_files/dashboard.kv")
        self.sm = ScreenManager()
        self.login_screen = LoginScreen(name="login")
        self.dashboard_screen = DashboardScreen(name="dashboard")
        self.sm.add_widget(self.login_screen)
        self.sm.add_widget(self.dashboard_screen)
        return self.sm

    def login(self, username, password):
        print(f"Tentative de connexion avec : {username} / {password}")
        role = "admin" if username == "admin" else "client"
        self.dashboard_screen.load_role(role)
        self.sm.current = "dashboard"

if __name__ == "__main__":
    NetworkApp().run()