from kivymd.app import MDApp
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager
from screens.login_screen import LoginScreen
from screens.dashboard_screen import DashboardScreen
from utils.lang import Translator
from kivymd.uix.menu import MDDropdownMenu


class NetworkApp(MDApp):
    def build(self):
        print("🛠️ Lancement de l'application...")
        self.lang = Translator(lang="fr")
        self.theme_cls.primary_palette = "Blue"

        # Charger les fichiers .kv
        Builder.load_file("kivy_files/login.kv")
        Builder.load_file("kivy_files/dashboard.kv")

        # Menu déroulant pour la langue
        self.lang_menu = MDDropdownMenu(
            items=[
                {"text": "Français", "on_release": lambda x="fr": self.switch_language(x)},
                {"text": "English", "on_release": lambda x="en": self.switch_language(x)},
            ],
            width_mult=3
        )

        # ScreenManager avec écrans instanciés une fois
        self.screen_manager = ScreenManager()
        self.login_screen = LoginScreen(name="login")
        self.dashboard_screen = DashboardScreen(name="dashboard")

        self.screen_manager.add_widget(self.login_screen)
        self.screen_manager.add_widget(self.dashboard_screen)

        self.screen_manager.current = "login"  # on démarre sur l'écran de connexion
        return self.screen_manager

    def switch_language(self, lang):
        print(f"[INFO] Changement de langue vers : {lang}")
        self.lang.set_language(lang)

        # Mise à jour dynamique des textes
        for screen in self.screen_manager.screens:
            if hasattr(screen, "update_language"):
                screen.update_language()

    def toggle_nav_drawer(self):
        try:
            nav_drawer = self.root.get_screen("dashboard").ids.nav_drawer
            nav_drawer.set_state("toggle")
        except Exception as e:
            print(f"[ERREUR] toggle_nav_drawer(): {e}")

    def open_lang_menu(self, button):
        self.lang_menu.caller = button
        self.lang_menu.open()

    def open_profile(self):
        print("🧑 Ouverture du profil utilisateur (à implémenter)")


if __name__ == "__main__":
    try:
        NetworkApp().run()
    except Exception as e:
        import traceback
        print("[ERREUR FATALE] L'application s'est arrêtée brutalement :")
        traceback.print_exc()
        input("Appuie sur Entrée pour quitter...")
