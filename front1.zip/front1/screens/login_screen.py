from kivymd.uix.screen import MDScreen
from kivy.clock import Clock
from kivy.app import App


class LoginScreen(MDScreen):
    def on_pre_enter(self):
        Clock.schedule_once(self.load_texts)

    def load_texts(self, *args):
        self.update_language()

    def update_language(self):
        tr = App.get_running_app().lang.gettext
        self.ids.login_title.text = tr("login_title")
        self.ids.username.hint_text = tr("username")
        self.ids.password.hint_text = tr("password")
        self.ids.login_btn.text = tr("login")
        self.ids.language_label.text = tr("language")

    def do_login(self):
        username = self.ids.username.text.strip()
        password = self.ids.password.text.strip()

        role = "admin" if username == "admin" else "client"
        print(f"[INFO] Connexion en tant que : {role}")

        self.manager.current = "dashboard"

        try:
            dashboard = self.manager.get_screen("dashboard")
            Clock.schedule_once(lambda dt: dashboard.load_role(role), 0.2)
        except Exception as e:
            print(f"[ERREUR] Impossible de charger le rôle dans le dashboard : {e}")

    def change_language(self, lang):
        App.get_running_app().switch_language(lang)
