from kivymd.uix.screen import MDScreen
from kivy.app import App


class DashboardScreen(MDScreen):
    def load_role(self, role):
        self.role = role
        self.ids.role_label.text = f"Rôle : {role}"
        self.ids.export_btn.disabled = role != "admin"

    def update_stats(self, traffic="0 Ko/s", protocol="HTTP: 0%", anomaly="Aucune anomalie"):
        self.ids.network_stats.text = f"Trafic actuel : {traffic}"
        self.ids.protocol_stat.text = protocol
        self.ids.anomaly_stat.text = anomaly

    def update_language(self):
        tr = App.get_running_app().lang.gettext
        self.ids.stats_label.text = tr("stats_title")
        self.ids.devices_label.text = tr("devices_title")
        self.ids.logs_label.text = tr("logs_title")
        self.ids.graphs_label.text = tr("graphs_title")
        self.ids.export_btn.text = tr("export_logs")
        self.ids.contact_btn.text = tr("contact_admin")
        self.ids.profile_btn.text = tr("profile")
        # le rôle reste inchangé, on ne le retraduit pas
