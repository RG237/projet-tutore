from flask import Flask, request, jsonify
import sqlite3
import os

app = Flask(__name__)
DB_NAME = "logs_received.db"

# === Initialisation de la base de données ===
def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS received_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            event_type TEXT NOT NULL,
            source_ip TEXT NOT NULL,
            details TEXT
        )
    """)
    conn.commit()
    conn.close()

# === Endpoint pour recevoir des logs ===
@app.route("/api/logs", methods=["POST"])
def receive_log():
    data = request.get_json()
    try:
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute("""
            INSERT INTO received_logs (timestamp, event_type, source_ip, details)
            VALUES (?, ?, ?, ?)
        """, (data["timestamp"], data["event_type"], data["source_ip"], data["details"]))
        conn.commit()
        conn.close()
        return jsonify({"status": "success", "message": "Log reçu et stocké"}), 201
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

# === Endpoint pour consulter les logs enregistrés ===
@app.route("/api/logs", methods=["GET"])
def list_logs():
    try:
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        c.execute("SELECT timestamp, event_type, source_ip, details FROM received_logs")
        logs = [{"timestamp": row[0], "event_type": row[1], "source_ip": row[2], "details": row[3]} for row in c.fetchall()]
        conn.close()
        return jsonify({"status": "success", "logs": logs}), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

# === Lancement du serveur ===
if __name__ == "__main__":
    init_db()
    app.run(host="127.0.0.1", port=5000)
