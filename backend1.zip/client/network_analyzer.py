import platform
import os
import requests
import matplotlib.pyplot as plt
from datetime import datetime
from collections import defaultdict, Counter
import logging
import subprocess
import sqlite3
import bcrypt
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.clock import Clock
from scapy.all import *
from scapy.layers.dot11 import Dot11Beacon
from sklearn.ensemble import IsolationForest

# Configuration du logging
logging.basicConfig(level=logging.INFO)

DB_PATH = "data_base.db"
IS_ANDROID = platform.system() == "Linux" and "ANDROID_ARGUMENT" in os.environ

# === Interface de connexion utilisateur ===
class LoginScreen(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation='vertical', **kwargs)
        self.label = Label(text="Connexion")
        self.username = TextInput(hint_text="Nom d'utilisateur")
        self.password = TextInput(hint_text="Mot de passe", password=True)
        self.login_btn = Button(text="Se connecter", on_press=self.login)
        self.add_widget(self.label)
        self.add_widget(self.username)
        self.add_widget(self.password)
        self.add_widget(self.login_btn)

    def login(self, instance):
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT role, password FROM users WHERE username = ?", (self.username.text,))
        user = c.fetchone()
        if user and bcrypt.checkpw(self.password.text.encode(), user[1]):
            App.get_running_app().role = user[0]
            App.get_running_app().switch_to_analyzer()
        else:
            self.label.text = "Échec de la connexion"

# === Application principale Kivy ===
class NetworkAnalyzerApp(App):
    def build(self):
        self.role = None
        self.login_screen = LoginScreen()
        return self.login_screen

    def switch_to_analyzer(self):
        self.analyzer = NetworkAnalyzer(self.role)
        self.layout = BoxLayout(orientation='vertical')
        self.status_label = Label(text=f"Connecté en tant que {self.role}")
        self.start_btn = Button(text="Démarrer la capture", on_press=self.start_capture)
        self.export_btn = Button(text="Exporter les logs", on_press=self.export_logs)
        self.layout.add_widget(self.status_label)
        self.layout.add_widget(self.start_btn)
        self.layout.add_widget(self.export_btn)
        if self.role == "admin":
            self.admin_btn = Button(text="Afficher statistiques", on_press=self.show_graph)
            self.layout.add_widget(self.admin_btn)
        self.root.clear_widgets()
        self.root.add_widget(self.layout)

    def start_capture(self, instance):
        self.status_label.text = "Capture en cours..."
        Clock.schedule_once(lambda dt: self.run_capture(), 0.1)

    def run_capture(self):
        self.analyzer.start_capture(duration=30)
        self.status_label.text = f"Capture terminée\nAlertes: {len(self.analyzer.alerts)}"

    def export_logs(self, instance):
        filename = self.analyzer.export_report()
        self.status_label.text = f"Logs exportés : {filename}"

    def show_graph(self, instance):
        self.analyzer.generate_protocol_graph()
        self.status_label.text = "Graphique généré : protocol_stats.png"

# === Analyseur réseau principal ===
class NetworkAnalyzer:
    def __init__(self, user_role):
        self.role = user_role
        self.setup_database()
        self.protocol_stats = defaultdict(int)
        self.alerts = []
        self.event_counter = Counter()
        self.capture_active = False
        self.interface = self.detect_interface()
        self.anomaly_model = IsolationForest(contamination=0.1)
        self.training_data = []

    def setup_database(self):
        self.conn = sqlite3.connect(DB_PATH)
        self.c = self.conn.cursor()
        self.c.execute("""
            CREATE TABLE IF NOT EXISTS network_logs (
                id INTEGER PRIMARY KEY,
                timestamp TEXT,
                event_type TEXT,
                source_ip TEXT,
                details TEXT
            )
        """)
        self.c.execute("""
            CREATE TABLE IF NOT EXISTS config (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        """)
        self.c.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password BLOB NOT NULL,
                role TEXT NOT NULL CHECK (role IN ('admin', 'utilisateur'))
            )
        """)
        self.c.execute("SELECT * FROM users WHERE username = 'admin'")
        if not self.c.fetchone():
            hashed_pw = bcrypt.hashpw("admin123".encode(), bcrypt.gensalt())
            self.c.execute("INSERT INTO users (username, password, role) VALUES (?, ?, ?)",
                           ("admin", hashed_pw, "admin"))
        self.conn.commit()

    def detect_interface(self):
        if IS_ANDROID:
            return "wlan0"
        try:
            interfaces = get_windows_if_list()
            for iface in interfaces:
                if "Wi-Fi" in iface.description or "Wireless" in iface.description:
                    return iface.name
            return conf.iface
        except Exception:
            return conf.iface

    def log_event(self, event_type, source, details):
        self.c.execute(
            "INSERT INTO network_logs VALUES (NULL, ?, ?, ?, ?)",
            (datetime.now().isoformat(), event_type, source, str(details))
        )
        self.conn.commit()
        self.send_log_to_server(event_type, source, details)

    def start_capture(self, duration=30, bpf_filter=None):
        try:
            self.capture_active = True
            sniff(
                iface=self.interface,
                prn=self.process_packet,
                timeout=duration,
                filter=bpf_filter,
                stop_filter=lambda _: not self.capture_active
            )
        except Exception as e:
            self.log_event("ERROR", "CAPTURE", str(e))
        finally:
            self.capture_active = False
            self.analyze_anomalies()
            self.generate_protocol_graph()

    def process_packet(self, packet):
        if not self.capture_active:
            return
        src_ip = packet[IP].src if IP in packet else "UNKNOWN"
        if TCP in packet and packet[TCP].flags == "S":
            self.event_counter[src_ip] += 1
            if self.event_counter[src_ip] >= 5:
                if src_ip not in [a.split()[-1] for a in self.alerts]:
                    self.alerts.append(f"Port Scan détecté depuis {src_ip}")
                    self.log_event("ALERT", src_ip, "Port Scan (5 SYN)")
                    if self.role == "admin":
                        self.block_ip(src_ip)
        proto = packet.summary().split()[0]
        self.protocol_stats[proto] += 1
        self.training_data.append([len(packet), packet.time % 60])

    def analyze_anomalies(self):
        if len(self.training_data) > 10:
            try:
                predictions = self.anomaly_model.fit_predict(self.training_data)
                for i, val in enumerate(predictions):
                    if val == -1:
                        self.log_event("ANOMALY", "LOCAL", f"Anomalie ML: {self.training_data[i]}")
                        self.alerts.append("Anomalie détectée par ML")
            except Exception as e:
                self.log_event("ERROR", "ML", str(e))

    def block_ip(self, ip):
        try:
            if IS_ANDROID:
                subprocess.run(["iptables", "-A", "INPUT", "-s", ip, "-j", "DROP"], check=True)
            else:
                subprocess.run([
                    "netsh", "advfirewall", "firewall", "add", "rule",
                    f"name=Block {ip}", "dir=in", "action=block", f"remoteip={ip}"
                ], check=True)
            self.log_event("BLOCK", ip, "Blocage par admin")
        except Exception as e:
            self.log_event("ERROR", "FIREWALL", str(e))

    def export_report(self):
        filename = f"network_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        with open(filename, "w") as f:
            f.write("Event,Source,Details\n")
            for row in self.c.execute("SELECT event_type, source_ip, details FROM network_logs"):
                f.write(f"{row[0]},{row[1]},{row[2]}\n")
        return filename

    def generate_protocol_graph(self):
        try:
            if not self.protocol_stats:
                return
            plt.bar(self.protocol_stats.keys(), self.protocol_stats.values())
            plt.xlabel("Protocoles")
            plt.ylabel("Nombre de paquets")
            plt.title("Statistiques des protocoles capturés")
            plt.xticks(rotation=45)
            plt.tight_layout()
            plt.savefig("protocol_stats.png")
        except Exception as e:
            self.log_event("ERROR", "GRAPH", str(e))

    def send_log_to_server(self, event_type, source, details):
        try:
            url = "http://127.0.0.1:5000/api/logs"  # À remplacer par l'IP réelle du serveur distant
            data = {
                "timestamp": datetime.now().isoformat(),
                "event_type": event_type,
                "source_ip": source,
                "details": details
            }
            requests.post(url, json=data, timeout=5)
        except Exception as e:
            print("Erreur d'envoi distant :", e)

if __name__ == "__main__":
    if IS_ANDROID:
        NetworkAnalyzerApp().run()
    else:
        analyzer = NetworkAnalyzer(user_role="admin")
        analyzer.start_capture()
        print("Analyse terminée. Export du rapport...")
        print(f"Rapport exporté : {analyzer.export_report()}")
