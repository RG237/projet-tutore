import json
import os

class Translator:
    def __init__(self, lang="fr"):
        self.lang = lang
        self.translations = {}
        self.load()

    def load(self):
        try:
            path = os.path.join("translations", f"{self.lang}.json")
            with open(path, encoding="utf-8") as f:
                self.translations = json.load(f)
        except Exception:
            self.translations = {}

    def gettext(self, key):
        return self.translations.get(key, key)

    def set_language(self, lang):
        self.lang = lang
        self.load()