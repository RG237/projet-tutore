from kivymd.uix.screen import MDScreen
from kivy.lang import Builder
from kivy.properties import ObjectProperty
from kivy.clock import Clock

Builder.load_file("kivy_files/login.kv")

class LoginScreen(MDScreen):
    app = ObjectProperty()

    def on_pre_enter(self):
        Clock.schedule_once(self.load_texts)

    def load_texts(self, *args):
        tr = self.manager.app.lang.gettext
        self.ids.login_title.text = tr("login_title")
        self.ids.username.hint_text = tr("username")
        self.ids.password.hint_text = tr("password")
        self.ids.login_btn.text = tr("login")
        self.ids.language_label.text = tr("language")

    def do_login(self):
        username = self.ids.username.text
        password = self.ids.password.text
        role = "admin" if username == "admin" else "client"
        self.manager.current = "dashboard"
        self.manager.get_screen("dashboard").load_role(role)

    def change_language(self, lang):
        self.manager.app.switch_language(lang)