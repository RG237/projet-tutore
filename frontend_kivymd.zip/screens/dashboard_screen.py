from kivymd.uix.screen import MDScreen
from kivy.lang import Builder
Builder.load_file("kivy_files/dashboard.kv")

class DashboardScreen(MDScreen):
    def load_role(self, role):
        self.ids.role_label.text = f"Rôle : {role}"
        self.ids.export_btn.disabled = role != "admin"